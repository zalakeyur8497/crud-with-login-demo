<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>

<body>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous">
    </script>
    <br><br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-10">

                <table class="table table-bordered">
                 
                    <caption>
                        <h1>SHOW PAGE</h1>
                    </caption>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>Pw</th>
                        <th>
                            Action
                            <a href="<?php echo e(route('index')); ?>" class="btn btn-success btn-sm">ADD-USER</a>
                            <a href="<?php echo e(route('logout')); ?>" class="btn btn-warning btn-sm">LOG-OUT</a>
                        </th>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td><?php echo e($row->pw); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit', $row->id)); ?>" class="btn btn-secondary">Edit</a>
                                <a href="<?php echo e(route('delete', $row->id)); ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\test\resources\views/show.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>

<body>
    <h1 style="text-align: center">REGISTER PAGE</h1>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous">
    </script>
    <br><br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <form method="post">
                    @csrf
                    @method('post')
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="email" class="form-control" placeholder="enter yout email">
                        <label>Passwored</label>
                        <input type="password" name="pw" class="form-control" placeholder="Enter your Password">
                    </div>
                    <br>
                    <input type="submit" id="submit" class="btn btn-primary">
                    <a href="{{ route('login') }}" class="btn btn-secondary">LOG-IN</a>
                    <a href="{{ route('show') }}" class="btn btn-warning">SHOW</a>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script>
        $('#submit').click(function() {
            $.ajax({
                url: 'formsubmit',
                data: $('form').serialize(),
                type: 'post',
                success: function(result) {
                    alert(result);
                }
            });
        });
    </script>
</body>

</html>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>

<body>
    {{-- <h1 style="text-align: center">UPDATE PAGE</h1> --}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous">
    </script>
    <br><br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <caption>
                    <h1>UPDATE PAGE</h1>
                </caption>
                <form method="post">
                    @csrf
                    @method('post')
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="email" class="form-control" value="{{ $data[0]->email }}">
                        <label>Password</label>
                        <input type="text" name="pw" class="form-control" value="{{ $data[0]->pw }}">
                    </div>
                    <br>
                    <input type="hidden" id="id" name="id" value="{{ $data[0]->id }}">
                    <input type="submit" id="update" value="update" class="btn btn-info">
                    <a href="{{ route('show') }}" class="btn btn-success">Show</a>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script>
        $('#update').click(function() {
            $.ajax({
                url: '{{ url("/update/".$data[0]->id) }}',
                data: $('form').serialize(),
                type: 'post',
                success: function(result) {
                    alert(result);
                }
            });
        });
    </script>
</body>

</html>

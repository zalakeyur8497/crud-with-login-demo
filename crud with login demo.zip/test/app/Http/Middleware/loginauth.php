<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class loginauth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {

        // if (!session()->has('user') && $request->path() != 'login' &&  $request->path() != 'index') {
        //     return redirect('login')->with('fail', 'Plz. login first');
        // }
        // if (session()->has('user') && $request->path() == 'login' ||  $request->path() == 'index') {

        //     return back();
        // } else {


        //     return $next($request);
        // }
    }
}

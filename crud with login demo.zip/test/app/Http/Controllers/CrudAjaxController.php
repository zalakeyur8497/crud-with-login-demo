<?php

namespace App\Http\Controllers;

use App\Models\CrudAjax;
use App\Http\Requests\StoreCrudAjaxRequest;
use App\Http\Requests\UpdateCrudAjaxRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class CrudAjaxController extends Controller
{

    public function insert(Request $request)
    {
        $email = $request->post('email');
        $pw = $request->post('pw');
        // DB::table('crud_ajaxes')->insert(array(['email' => $email, 'pw' => $pw]));
       DB::table('crud_ajaxes')->insert(array(['email' => $email, 'pw' => Hash::make($pw)]));
        return redirect()->route('/show');
        // $model = new CrudAjax;
        // $model->eamil=$request->get('email');
        // $model->pw=$request->get('pw');
        // $check =  $model->save();

        // if($check){
        //         echo "success";
        // }else{
        //     echo "check code";
        // }
    }

    public function index()
    {
        return view('index');
    }

    public function show(Request $request)
    {
        $arr['data'] =  DB::table('crud_ajaxes')->get();

        return view('show', $arr);
    }

    public function edit(Request $request, $id)
    {

        $arr['data'] = DB::table('crud_ajaxes')->where(['id' => $id])->get();
        return view('edit', $arr);
    }

    public function update(Request $request, $id)
    {
        $email = $request->post('email');
        $pw = $request->post('pw');
        $arr['data'] =  DB::table('crud_ajaxes')->where(['id' => $id])->update(['email' => $email, 'pw' => $pw]);
        return view('/show');
        return redirect()->route('show');
    }

    public function delete(Request $request, $id)
    {
        $arr['data'] =  DB::table('crud_ajaxes')->where(['id' => $id])->delete();
        return redirect()->route('show');
    }
    public function login()
    {
        return view('login');
    }


    public function logincheck(Request $request)
    {
        $userinfo = CrudAjax::where('email', '=', $request->email)->first();
        if (!$userinfo) {
            echo "please check email";
        } else {
            if (Hash::check($request->pw, $userinfo->pw)) {
                $request->session()->put('user', $userinfo->id);
                return redirect()->route('show');
            } else {
                echo "please enter correct password";
            }
        }
        // $result = DB::table('crud_ajaxes')->get();
        // if ($result->email == $request->input('email') && $result->pw == $request->input('pw')) {
        //     echo "Success";
        // } else {
        //     echo "wrong username or password";
        // }
    }


    public function logout()
    {
        
        if(session()->has('user')){
            session()->pull('user');
            return redirect()->route('login');
            //return view('login');
        }

    }
}



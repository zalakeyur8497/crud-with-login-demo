<?php

use App\Http\Controllers\CrudAjaxController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::any('/', function (){
//     return view('index');
// });
Route::any('/index',[CrudAjaxController::class,'index'])->name('index');
Route::post('/formsubmit',[CrudAjaxController::class,'insert']);
Route::get('/show',[CrudAjaxController::class,'show'])->name('show');
Route::any('/edit/{id}',[CrudAjaxController::class,'edit'])->name('edit');
Route::post('/update/{id}',[CrudAjaxController::class,'update']);
Route::get('/delete/{id}',[CrudAjaxController::class,'delete'])->name('delete');

Route::any('/login',[CrudAjaxController::class,'login'])->name('login');
Route::post('/logincheck',[CrudAjaxController::class,'logincheck'])->name('logincheck');
Route::any('/logout',[CrudAjaxController::class,'logout'])->name('logout');




// Route::group(['middleware'=>'loginauth','PreventBackHistory'],function(){

    
// });